package com.example.myfoodapp.Listeners;

public interface RecipeClickListener {
    void onRecipeClicked(String id);
}
