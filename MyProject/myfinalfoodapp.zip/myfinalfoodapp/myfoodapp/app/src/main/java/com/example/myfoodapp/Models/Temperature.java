package com.example.myfoodapp.Models;

public class Temperature {
    public double number;
    public String unit;
}
