package com.example.myfoodapp.Models;

public class Us {
    public double amount;
    public String unitShort;
    public String unitLong;
}
