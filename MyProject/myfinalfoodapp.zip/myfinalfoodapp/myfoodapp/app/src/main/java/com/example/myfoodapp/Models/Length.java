package com.example.myfoodapp.Models;

public class Length {
    public int number;
    public String unit;
}
